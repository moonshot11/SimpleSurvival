//==========================================//
//                                          //
//              SimpleSurvival              //
//                  v0.1.2                  //
//                                          //
//      A mod for Kerbal Space Program      //
//              by moonshot11               //
//                                          //
//==========================================//

For an illustrated user guide, please visit this URL:

https://github.com/moonshot11/SimpleSurvival

VERSION INFO
    SimpleSurvival v0.1.2
    Tested with Kerbal Space Program version 1.10.1

LICENSE
    SimpleSurvival: GNU General Public License v3.0
    ModuleManager 4.1.4: created by Ialdaboth (https://github.com/Ialdabaoth)

INSTALLATION
    From SimpleSurvival.zip, extract the contents of the GameData folder into your "Kerbal Space Program\GameData" folder.  Make sure to copy the ModuleManager DLL as well!  If the mod has been installed correctly, then you will find SimpleSurvival's DLL at:

    "Kerbal Space Program\GameData\SimpleSurvival\SimpleSurvival.dll"

AUTHOR INFO
    Github: moonshot11
    Reddit: moonshot11_ksp
    Spacedock: moonshot11
